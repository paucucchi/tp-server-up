#!/bin/bash

# Validar argumentos
if [[ "$1" == "-h" || $# -ne 2 ]]; then
	echo "Para hacer backup ingrese: $0 <directorio_origen> <directorio_destino>"
	echo "Por ejemplo: $0 /var/log /backup_dir"
	exit 1
fi

# Variables
ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +"%Y%m%d")
NOMBRE_BACKUP=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz

# Verificar que los directorios origen y destino existan y esten montados
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error - El directorio origen $ORIGEN no existe o no esta montado"
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error - El directorio destino $DESTINO no existe o no esta montado"
	exit 1
fi

# Crear el backup
tar -czf "$DESTINO/$NOMBRE_BACKUP" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"
if [[ $? -eq 0 ]]; then
	echo "El backup se hizo correctamente: $DESTINO/$NOMBRE_BACKUP"
else
	echo "Ocurrió un error al realizar el backup"
	exit 1
fi
